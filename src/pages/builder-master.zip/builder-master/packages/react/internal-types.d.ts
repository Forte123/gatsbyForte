declare module 'rollup-plugin-replace';
declare module 'rollup-plugin-re';
declare module 'rollup-plugin-alias';
