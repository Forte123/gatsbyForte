module.exports = require('./dist/inferno.js')
