module.exports = require('./dist/preact.js')
