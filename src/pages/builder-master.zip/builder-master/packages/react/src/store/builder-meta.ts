import React from 'react'

export const BuilderMetaContext = React.createContext({
  emailMode: false,
  ampMode: false
})
