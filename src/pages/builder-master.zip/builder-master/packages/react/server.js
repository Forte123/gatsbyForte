module.exports = require('./dist/server.js')
