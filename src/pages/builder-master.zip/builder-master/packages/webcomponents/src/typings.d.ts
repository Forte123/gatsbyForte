declare module '*.json'
