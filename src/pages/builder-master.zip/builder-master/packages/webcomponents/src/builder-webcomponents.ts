// TODO: lazy load polyfill only when needed, always render into
// elements by tag name
import '@webcomponents/custom-elements'
import 'es6-promise/auto'
export * from './core'
