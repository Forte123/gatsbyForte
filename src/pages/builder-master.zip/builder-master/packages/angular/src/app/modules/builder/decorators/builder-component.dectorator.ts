import { BuilderComponent } from '@builder.io/sdk';

export const Block = BuilderComponent;
export { BuilderComponent };
