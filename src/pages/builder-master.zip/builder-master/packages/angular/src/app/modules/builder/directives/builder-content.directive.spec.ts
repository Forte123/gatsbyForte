import { BuilderContentDirective } from './builder-content.directive';

describe('BuilderContentDirective', () => {
  it('should create an instance', () => {
    // const directive = new BuilderContentDirective();
    // expect(directive).toBeTruthy();
    expect(true).toBeTruthy();
  });
});
