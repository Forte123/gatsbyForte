export * from './app/modules/builder/builder.module';
export * from './app/modules/builder/decorators/builder-component.dectorator';
export * from './app/modules/builder/services/builder.service';
export {
  RouteEvent,
} from './app/modules/builder/components/builder-component/builder-component.component';
