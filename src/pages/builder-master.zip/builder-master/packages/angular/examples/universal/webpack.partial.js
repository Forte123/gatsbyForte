module.exports = {
  node: {
    https: 'empty'
  }
}
