import { Component } from "@angular/core";

@Component({
  selector: "foo",
  template: "hi"
})
export class FooComponent {
}
