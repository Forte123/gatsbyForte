import { Builder } from "../builder.class";

export const builder = new Builder(null, undefined, undefined, true)
Builder.singletonInstance = builder;
