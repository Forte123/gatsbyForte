declare module '*.json';
declare module 'es6-promise';
