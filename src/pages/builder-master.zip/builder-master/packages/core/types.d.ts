declare module 'unique-selector' {
  let unique: (key: Element) => string;
  export default unique;
}
